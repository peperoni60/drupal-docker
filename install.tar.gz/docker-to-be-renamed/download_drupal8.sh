#!/usr/bin/env bash
# initialize a drupal 8 environment using drush
. environment.env

CONTAINER=$APACHE_NAME
REMOTEDIR=/var/www/tmp
TMPDIR=../www/tmp
INITFILE=init.sh
mkdir $TMPDIR 2> /dev/null
cat > $TMPDIR/$INITFILE << EOF
#!/usr/bin/env bash
BASEDIR=/var/www
cd \$BASEDIR
echo "*************************************************************************************"
echo This will remove existing files from \$BASEDIR and download a new Drupal 8 instance.
echo "Do you want to continue? (y/n)."
echo "*************************************************************************************"
while true; do
    read yn
    case \$yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done
echo "processing..."
rm -R drupal-8* 2> /dev/null
rm -R docroot/* 2> /dev/null
drush dl drupal-8
mv drupal-8*/* drupal-8*/.??* docroot
rmdir drupal-8*
cd docroot
mkdir modules/contrib
mkdir modules/custom
mkdir themes/contrib
mkdir themes/custom
mkdir libraries 2> /dev/null
chown -R www-data:www-data \$BASEDIR/docroot/sites
EOF

chmod +x $TMPDIR/$INITFILE

docker exec -i $CONTAINER "$REMOTEDIR/$INITFILE"

rm $TMPDIR/$INITFILE


