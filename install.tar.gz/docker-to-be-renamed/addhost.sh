#!/usr/bin/env bash
# Script to add/remove the project's hosts to/from /etc/hosts
# If a host's IP is empty, it's entry is removed from /etc/hosts
# *************************************
# * This script must be run as sudo!  *
# *************************************

set -e

. environment.env

TMPFILE=../www/tmp/hosts
HOSTS=/etc/hosts
cat $HOSTS > ${TMPFILE}
if [ -a ${TMPFILE}.* ]
  then
  rm ${TMPFILE}.*
fi

if [ ! -z "$APACHE_HOSTNAME" ]
    then
    grep -v "$APACHE_HOSTNAME" $TMPFILE > ${TMPFILE}.999
    mv ${TMPFILE}.999 $TMPFILE
    if [ ! -z "$APACHE_IP" ]
        then
        echo "$APACHE_IP" "$APACHE_HOSTNAME" >> ${TMPFILE}.001
    fi
fi

if [ ! -z "$MYSQL_HOSTNAME" ]
    then
    grep -v "$MYSQL_HOSTNAME" $TMPFILE > ${TMPFILE}.999
    mv ${TMPFILE}.999 $TMPFILE
    if [ ! -z "$MYSQL_IP" ]
        then
        echo "$MYSQL_IP" "$MYSQL_HOSTNAME" >> ${TMPFILE}.001
    fi
fi
cat ${TMPFILE}.001 > ${TMPFILE}.999
cat $TMPFILE >> ${TMPFILE}.999
mv ${TMPFILE}.999 $TMPFILE

cat $TMPFILE > $HOSTS

rm $TMPFILE ${TMPFILE}.*

echo "New $HOSTS file:"
cat $HOSTS


