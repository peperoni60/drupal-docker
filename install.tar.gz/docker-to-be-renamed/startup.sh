#!/usr/bin/env bash

# start docker containers
export COMPOSE_OPTIONS="--env-file=./environment.env"
docker-compose up
